"""
01 — LCC-HVDC link in an AC power flow (pandapower).

Sweeps the DC power order from 10 % to 100 % and, at every point, lets two pandapower
controllers settle the station:
  * LCCConverter   sets each converter's reactive demand from the overlap equations;
  * RPCFilterController switches AC-filter banks (minimum filter + Q band + U limits).

Companion to modules 1 and 4 of the GridPulse HVDC Controller Lab.
Outputs: outputs/01_lcc_link_sweep.csv and outputs/01_lcc_link_sweep.png
"""
import pathlib
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pandapower as pp
import pandapower.control as control

from hvdc_pp import LCCConverter, RPCFilterController, build_lcc_link, operating_point

warnings.filterwarnings("ignore", category=FutureWarning)
OUT = pathlib.Path(__file__).with_name("outputs")
OUT.mkdir(exist_ok=True)

P_RATED = 1000.0        # MW
ALPHA, GAMMA, DX = 15.0, 18.0, 0.08
LOSSES = 0.015          # DC line + converter losses (fraction of P)

net, ids = build_lcc_link(p_rated_mw=P_RATED, scr_rect=5.0, scr_inv=4.0, n_banks=6, qb_pu=0.12, banks_on=1)
for side, angle in (("rect", ALPHA), ("inv", GAMMA)):
    LCCConverter(net, ids[side]["load"], angle_deg=angle, dx=DX, p_rated_mw=P_RATED)
    RPCFilterController(net, ids[side]["shunt"], ids[side]["load"], angle_deg=angle, dx=DX, p_rated_mw=P_RATED,
                        mode="Q", band_pu=0.08, u_min=0.95, u_max=1.05, min_filter_p=(0.02, 0.5), delay_steps=0,
                        scr_est=ids[side]["scr"])

rows = []
for p_pu in np.round(np.arange(0.1, 1.001, 0.1), 2):
    net.load.at[ids["rect"]["load"], "p_mw"] = p_pu * P_RATED
    net.load.at[ids["inv"]["load"], "p_mw"] = -p_pu * P_RATED * (1 - LOSSES)
    control.run_control(net, max_iter=60)
    op = operating_point(p_pu, gamma_ref_deg=GAMMA, dx=DX)
    row = {"P_order_pu": p_pu, "Id_pu": round(op.id_pu, 3)}   # tap changers hold alpha / gamma; Id from the DC circuit
    for side in ("rect", "inv"):
        b, s, l = ids[side]["bus"], ids[side]["shunt"], ids[side]["load"]
        q_conv = net.load.at[l, "q_mvar"]
        q_filt = -net.res_shunt.at[s, "q_mvar"]
        row.update({
            f"{side}_banks": int(net.shunt.at[s, "step"]),
            f"{side}_Qconv_Mvar": round(q_conv, 1),
            f"{side}_Qfilt_Mvar": round(q_filt, 1),
            f"{side}_Qexch_Mvar": round(q_filt - q_conv, 1),
            f"{side}_U_pu": round(net.res_bus.at[b, "vm_pu"], 4),
        })
    rows.append(row)

df = pd.DataFrame(rows)
pd.set_option("display.width", 200)
print(df.to_string(index=False))
df.to_csv(OUT / "01_lcc_link_sweep.csv", index=False)

fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
for side, c in (("rect", "tab:blue"), ("inv", "tab:orange")):
    ax[0].plot(df.P_order_pu, df[f"{side}_Qconv_Mvar"], "-", color=c, lw=2, label=f"{side}: converter Q")
    ax[0].step(df.P_order_pu, df[f"{side}_Qfilt_Mvar"], where="mid", color=c, ls="--", label=f"{side}: filters")
    ax[0].plot(df.P_order_pu, df[f"{side}_Qexch_Mvar"], ":", color=c, marker="o", ms=3, label=f"{side}: exchange")
    ax[1].plot(df.P_order_pu, df[f"{side}_U_pu"], color=c, marker="o", label=f"{side} AC bus")
ax[0].set(xlabel="DC power order [pu]", ylabel="Q [Mvar]", title="Converter demand, filters, exchange")
ax[1].axhline(1.05, color="r", ls="--", lw=1); ax[1].axhline(0.95, color="r", ls="--", lw=1)
ax[1].set(xlabel="DC power order [pu]", ylabel="U [pu]", title="AC voltage at the converter buses")
for a in ax:
    a.grid(alpha=0.3); a.legend(fontsize=8)
plt.tight_layout()
plt.savefig(OUT / "01_lcc_link_sweep.png", dpi=130)
print(f"\nSaved {OUT / '01_lcc_link_sweep.csv'} and .png")
