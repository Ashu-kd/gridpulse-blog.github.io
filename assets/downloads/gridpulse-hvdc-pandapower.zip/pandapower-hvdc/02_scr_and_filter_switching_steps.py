"""
02 — Short-circuit ratio and voltage step per filter bank (IEC 60909 with pandapower).

1. pandapower.shortcircuit (IEC 60909, max case) gives S_sc at each converter AC bus.
   SCR  = S_sc / P_dc,rated
   ESCR = (S_sc - Q_filters) / P_dc,rated          (filters reduce the effective strength)
2. Each filter bank is then switched in one at a time with a power flow, and the
   simulated voltage step is compared with the textbook estimate  dU ~ Q_bank / S_sc.

Companion to module 4 (Reactive Power & Filters) of the GridPulse HVDC Controller Lab.
Outputs: outputs/02_scr_voltage_steps.csv and outputs/02_scr_voltage_steps.png
"""
import pathlib
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import pandapower as pp
import pandapower.shortcircuit as sc

from hvdc_pp import build_lcc_link

warnings.filterwarnings("ignore", category=FutureWarning)
OUT = pathlib.Path(__file__).with_name("outputs")
OUT.mkdir(exist_ok=True)

P_RATED, N_BANKS, QB_PU = 1000.0, 6, 0.12
results = []
fig, ax = plt.subplots(figsize=(7, 4.5))

for scr_design in (2.0, 3.0, 5.0, 8.0):
    net, ids = build_lcc_link(p_rated_mw=P_RATED, scr_rect=scr_design, scr_inv=scr_design, n_banks=N_BANKS,
                              qb_pu=QB_PU, banks_on=0)
    bus = ids["inv"]["bus"]
    sc.calc_sc(net, case="max", bus=bus)
    s_sc = net.res_bus_sc.at[bus, "skss_mw"]                 # initial symmetrical short-circuit power [MVA]
    u_steps, u = [], []
    for n in range(N_BANKS + 1):
        net.shunt.at[ids["inv"]["shunt"], "step"] = n
        pp.runpp(net)
        u.append(net.res_bus.at[bus, "vm_pu"])
    u_steps = [100 * (u[i + 1] - u[i]) for i in range(N_BANKS)]
    q_bank = QB_PU * P_RATED
    results.append({
        "design_SCR": scr_design,
        "S_sc_MVA (IEC 60909)": round(s_sc, 0),
        "SCR": round(s_sc / P_RATED, 2),
        "ESCR (all banks in)": round((s_sc - N_BANKS * q_bank) / P_RATED, 2),
        "dU first bank % (power flow)": round(u_steps[0], 2),
        "dU estimate % (Qb/Ssc)": round(100 * q_bank / s_sc, 2),
        "U with all banks [pu]": round(u[-1], 4),
    })
    ax.plot(range(N_BANKS + 1), u, marker="o", label=f"SCR ≈ {s_sc / P_RATED:.1f}")

df = pd.DataFrame(results)
pd.set_option("display.width", 200)
print(df.to_string(index=False))
df.to_csv(OUT / "02_scr_voltage_steps.csv", index=False)

ax.axhline(1.05, color="r", ls="--", lw=1)
ax.set(xlabel="filter banks in service (no DC power)", ylabel="AC bus voltage [pu]",
       title=f"Voltage rise from {N_BANKS} × {QB_PU * P_RATED:.0f} Mvar banks vs system strength")
ax.grid(alpha=0.3); ax.legend()
plt.tight_layout()
plt.savefig(OUT / "02_scr_voltage_steps.png", dpi=130)
print(f"\nSaved {OUT / '02_scr_voltage_steps.csv'} and .png")
