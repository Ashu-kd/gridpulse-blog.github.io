"""
03 — Reactive power control (RPC) during a power ramp: pandapower time series.

The DC power ramps 0.1 → 1.0 → 0.1 pu. Every time step (1 s) pandapower solves the AC power
flow; the RPCFilterController switches filter banks when a condition has persisted for
`DELAY_S` seconds. Run it twice to compare a correctly sized dead-band with one that is
narrower than a bank (hunting).

pandapower tools used: DFData + ConstControl (profiles), run_timeseries, OutputWriter,
custom Controller classes.
Companion to module 4 of the GridPulse HVDC Controller Lab.
Outputs: outputs/03_rpc_<case>.csv, outputs/03_rpc_events_<case>.csv, outputs/03_rpc_timeseries.png
"""
import pathlib
import tempfile
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pandapower.control import ConstControl
from pandapower.timeseries import DFData, OutputWriter, run_timeseries

from hvdc_pp import LCCConverter, RPCFilterController, build_lcc_link

warnings.filterwarnings("ignore", category=FutureWarning)
OUT = pathlib.Path(__file__).with_name("outputs")
OUT.mkdir(exist_ok=True)

P_RATED, ANGLE, DX = 1000.0, 15.0, 0.08
RATE_PU_S, DWELL_S, DELAY_S = 0.01, 20, 2          # ramp rate, hold at min/max, switching delay


def power_profile():
    up = np.arange(0.1, 1.0 + 1e-9, RATE_PU_S)
    p = np.concatenate([np.full(DWELL_S, 0.1), up, np.full(DWELL_S, 1.0), up[::-1], np.full(DWELL_S, 0.1)])
    return pd.DataFrame({"p_rect_mw": p * P_RATED})


def run_case(name, band_pu, scr=4.0, bias_pu=0.0):
    net, ids = build_lcc_link(p_rated_mw=P_RATED, scr_rect=scr, scr_inv=scr, n_banks=6, qb_pu=0.12, banks_on=1)
    prof = power_profile()
    ds = DFData(prof)
    r = ids["rect"]
    ConstControl(net, element="load", variable="p_mw", element_index=[r["load"]], data_source=ds,
                 profile_name=["p_rect_mw"], order=0)
    LCCConverter(net, r["load"], angle_deg=ANGLE, dx=DX, p_rated_mw=P_RATED, order=1)
    rpc = RPCFilterController(net, r["shunt"], r["load"], angle_deg=ANGLE, dx=DX, p_rated_mw=P_RATED, mode="Q",
                              band_pu=band_pu, bias_pu=bias_pu, u_min=0.95, u_max=1.05, min_filter_p=(0.02, 0.5),
                              delay_steps=DELAY_S, scr_est=scr, order=2)
    # the inverter side is left out of service here to keep the plot readable
    net.load.at[ids["inv"]["load"], "in_service"] = False
    net.shunt.at[ids["inv"]["shunt"], "in_service"] = False

    with tempfile.TemporaryDirectory() as tmp:
        ow = OutputWriter(net, time_steps=prof.index, output_path=tmp, output_file_type=".json")
        ow.log_variable("res_bus", "vm_pu", index=[r["bus"]])
        ow.log_variable("load", "q_mvar", index=[r["load"]])
        ow.log_variable("res_shunt", "q_mvar", index=[r["shunt"]])
        ow.log_variable("shunt", "step", index=[r["shunt"]])
        run_timeseries(net, time_steps=prof.index, verbose=False)
        res = pd.DataFrame({
            "t_s": prof.index,
            "P_pu": prof.p_rect_mw.values / P_RATED,
            "U_pu": ow.output["res_bus.vm_pu"][r["bus"]].values,
            "Qconv_pu": ow.output["load.q_mvar"][r["load"]].values / P_RATED,
            "Qfilt_pu": -ow.output["res_shunt.q_mvar"][r["shunt"]].values / P_RATED,
            "banks": ow.output["shunt.step"][r["shunt"]].values,
        })
    res["Qexch_pu"] = res.Qfilt_pu - res.Qconv_pu
    ev = pd.DataFrame(rpc.events)
    res.to_csv(OUT / f"03_rpc_{name}.csv", index=False)
    ev.to_csv(OUT / f"03_rpc_events_{name}.csv", index=False)
    print(f"\n=== {name}: band ±{band_pu} pu, bank {0.12} pu, SCR {scr} -> {len(ev)} switching operations")
    print(ev.head(12).to_string(index=False) if len(ev) else "no switching")
    return res, band_pu, bias_pu


cases = [run_case("normal_band", 0.08), run_case("narrow_band_hunting", 0.04)]

fig, axes = plt.subplots(2, 2, figsize=(13, 7), sharex=True)
for col, (res, band, bias) in enumerate(cases):
    a = axes[0, col]
    a.plot(res.t_s, res.Qconv_pu, color="tab:orange", lw=2, label="converter Q (absorbed)")
    a.step(res.t_s, res.Qfilt_pu, where="post", color="tab:green", label="filters")
    a.plot(res.t_s, res.Qexch_pu, color="tab:blue", lw=2, label="Q exchange")
    a.axhline(bias + band, color="r", ls="--", lw=1); a.axhline(bias - band, color="r", ls="--", lw=1)
    a.set(ylabel="Q [pu]", title=f"dead-band ±{band} pu ({int(res.banks.diff().abs().sum())} operations)")
    a.legend(fontsize=8); a.grid(alpha=0.3)
    b = axes[1, col]
    b.plot(res.t_s, res.U_pu, color="tab:blue", label="AC voltage")
    b.axhline(1.05, color="r", ls="--", lw=1); b.axhline(0.95, color="r", ls="--", lw=1)
    b2 = b.twinx(); b2.step(res.t_s, res.banks, where="post", color="tab:green", alpha=0.7); b2.set_ylabel("banks")
    b.set(xlabel="time [s]", ylabel="U [pu]"); b.grid(alpha=0.3)
plt.suptitle("RPC filter switching during a 0.1 → 1.0 → 0.1 pu power ramp (pandapower time series)")
plt.tight_layout()
plt.savefig(OUT / "03_rpc_timeseries.png", dpi=130)
print(f"\nSaved results to {OUT}")
