"""
04 — VSC-HVDC link in pandapower's hybrid AC/DC power flow.

Station A regulates the DC voltage (DC slack) and its reactive power; station B dispatches
active power and regulates its AC voltage. The script
  1. sweeps the power order of station B from -1.0 to +1.0 pu and records DC voltages,
     DC-line losses and the reactive power station B needs to hold 1.0 pu at its PCC;
  2. sweeps station A's reactive power order to show how the PCC voltage moves on a
     weak (SCR 3) versus strong (SCR 5) AC system
     (the voltage sensitivity dU/dQ).

Sign conventions (pandapower load convention): res_vsc p_mw / q_mvar > 0 means the converter
absorbs from its AC bus. A positive power order at station B transfers power A -> B.

Uses pandapower >= 3.0 (create_bus_dc, create_line_dc_from_parameters, create_vsc).
Companion to the VSC P-Q lab and module 5 of the GridPulse HVDC Controller Lab.
Outputs: outputs/04_vsc_sweep.csv and outputs/04_vsc_hybrid.png
"""
import pathlib
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pandapower as pp

from hvdc_pp import build_vsc_link

warnings.filterwarnings("ignore", category=FutureWarning)
OUT = pathlib.Path(__file__).with_name("outputs")
OUT.mkdir(exist_ok=True)
P_RATED = 1000.0

# --- 1. active-power sweep ------------------------------------------------------------
net, ids = build_vsc_link(p_rated_mw=P_RATED, scr_a=5.0, scr_b=3.0, length_km=300)
A, B = ids["A"], ids["B"]
rows = []
for p_pu in np.round(np.arange(-1.0, 1.0001, 0.1), 2) + 0.0:
    net.vsc.at[B["vsc"], "control_value_dc"] = p_pu * P_RATED
    pp.runpp(net)
    rows.append({
        "P_order_B_pu (+ = A->B)": p_pu,
        "P_ac_A_MW": round(net.res_vsc.at[A["vsc"], "p_mw"], 1),
        "P_ac_B_MW": round(net.res_vsc.at[B["vsc"], "p_mw"], 1),
        "Q_B_Mvar (holds U=1)": round(net.res_vsc.at[B["vsc"], "q_mvar"], 1),
        "Vdc_A_pu": round(net.res_bus_dc.at[A["bus_dc"], "vm_pu"], 4),
        "Vdc_B_pu": round(net.res_bus_dc.at[B["bus_dc"], "vm_pu"], 4),
        "DC_line_loss_MW": round(net.res_line_dc.at[ids["line_dc"], "pl_mw"], 2),
        "U_A_pu": round(net.res_bus.at[A["bus"], "vm_pu"], 4),
    })
sweep = pd.DataFrame(rows)
pd.set_option("display.width", 220)
print(sweep.to_string(index=False))
sweep.to_csv(OUT / "04_vsc_sweep.csv", index=False)

# --- 2. reactive-power sweep at station A for two system strengths -------------------------
q_curves = {}
for scr in (3.0, 5.0):
    net2, ids2 = build_vsc_link(p_rated_mw=P_RATED, scr_a=scr, scr_b=5.0)
    net2.vsc.at[ids2["B"]["vsc"], "control_value_dc"] = -0.8 * P_RATED   # 800 MW transferred B -> A
    pts = []
    for q_pu in np.round(np.arange(-0.6, 0.6001, 0.05), 3):
        net2.vsc.at[ids2["A"]["vsc"], "control_value_ac"] = q_pu * P_RATED
        try:
            pp.runpp(net2)
        except Exception:                                               # outside the solvable region
            continue
        p = net2.res_vsc.at[ids2["A"]["vsc"], "p_mw"] / P_RATED
        q = net2.res_vsc.at[ids2["A"]["vsc"], "q_mvar"] / P_RATED
        pts.append((q_pu, net2.res_bus.at[ids2["A"]["bus"], "vm_pu"], p, q))
    q_curves[scr] = np.array(pts)

fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
ax[0].plot(sweep["P_order_B_pu (+ = A->B)"], sweep.Vdc_B_pu, "o-", label="V_dc at B")
ax[0].axhline(1.0, color="k", lw=0.8)
ax0b = ax[0].twinx(); ax0b.plot(sweep["P_order_B_pu (+ = A->B)"], sweep.DC_line_loss_MW, "s--", color="tab:red", label="DC line loss")
ax[0].set(xlabel="station B power order [pu]", ylabel="V_dc,B [pu]", title="DC voltage & losses (A = V_dc control)")
ax0b.set_ylabel("loss [MW]", color="tab:red")
ax[1].plot(sweep["P_order_B_pu (+ = A->B)"], sweep["Q_B_Mvar (holds U=1)"], "o-", color="tab:green")
ax[1].set(xlabel="station B power order [pu]", ylabel="Q_B absorbed [Mvar]", title="Q used by B to hold U_PCC = 1.0 (SCR 3)")
for scr, c in ((3.0, "tab:orange"), (5.0, "tab:blue")):
    d = q_curves[scr]
    ax[2].plot(d[:, 0], d[:, 1], "o-", ms=3, color=c, label=f"SCR {scr:g}")
ax[2].axhline(1.05, color="r", ls="--", lw=1); ax[2].axhline(0.95, color="r", ls="--", lw=1)
ax[2].set(xlabel="station A Q order, absorbed [pu]", ylabel="U_PCC,A [pu]",
          title="PCC voltage vs reactive power (A carries 0.8 pu)")
for a in ax:
    a.grid(alpha=0.3)
ax[2].legend(fontsize=8)
plt.tight_layout()
plt.savefig(OUT / "04_vsc_hybrid.png", dpi=130)
for scr, d in q_curves.items():
    du = (d[-1, 1] - d[0, 1]) / (d[-1, 0] - d[0, 0])
    print(f"SCR {scr:g}: dU/dQ_absorbed at station A ≈ {du:.3f} pu per pu Q (no-load estimate -1/SCR = {-1 / scr:.3f})")
print("The sensitivity exceeds 1/SCR because station A also carries 0.8 pu active power: the AC system is")
print("effectively weaker under load, which is exactly why weak-grid VSC stations need fast AC-voltage control.")
print(f"\nSaved {OUT / '04_vsc_sweep.csv'} and 04_vsc_hybrid.png")
