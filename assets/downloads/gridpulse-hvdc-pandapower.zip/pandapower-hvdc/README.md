# GridPulse HVDC studies with pandapower

Steady-state companion to the **GridPulse HVDC Controller Lab** (browser simulators).
The lab covers control *dynamics*; this repository reproduces the parts that belong in a
power-flow tool, using [pandapower](https://www.pandapower.org) (BSD-3 licence):

| Script | What it does | pandapower features | Lab module |
|---|---|---|---|
| `01_lcc_link_powerflow.py` | LCC link between two AC systems, P sweep 0.1–1.0 pu: converter Q, filter banks, exchange, AC voltages | `impedance` Thevenin equivalents, custom `Controller`s, `run_control` | 1, 4 |
| `02_scr_and_filter_switching_steps.py` | Short-circuit level, SCR / ESCR and voltage step per filter bank | `shortcircuit.calc_sc` (IEC 60909), stepped `shunt` | 4 |
| `03_rpc_filter_switching_timeseries.py` | Reactive power controller during a 0.1 → 1.0 → 0.1 pu ramp; normal vs too-narrow dead-band (hunting) | `run_timeseries`, `DFData`, `ConstControl`, `OutputWriter` | 4 |
| `04_vsc_hvdc_hybrid_powerflow.py` | Point-to-point VSC-HVDC: V_dc control vs P control, DC losses, Q to hold the PCC voltage, dU/dQ on weak and strong grids | hybrid AC/DC power flow: `create_bus_dc`, `create_line_dc_from_parameters`, `create_vsc` | VSC P-Q, 5 |

`hvdc_pp/` is a small reusable package:

* `lcc.py` – LCC equations: overlap angle, exact Q/P ratio, static operating point, extinction angle after a dip, critical dip for commutation failure.
* `networks.py` – test systems: two AC systems with a chosen SCR linked by LCC or VSC HVDC.
* `controllers.py` – `LCCConverter` (converter reactive demand from the overlap equations) and `RPCFilterController` (minimum filter, Q-band with operator bias, U-limit priority, switching delay, blocking of operations that would breach a U limit).

## Quick start

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows  (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
python 01_lcc_link_powerflow.py
python 02_scr_and_filter_switching_steps.py
python 03_rpc_filter_switching_timeseries.py   # ~1 min without numba
python 04_vsc_hvdc_hybrid_powerflow.py
pytest -q                                       # optional sanity tests
```

Results (CSV + PNG) are written to `outputs/`. Example outputs are included.

### Where this lives

This folder is `pandapower-hvdc/` inside the GridPulse website repository
(`Ashu-kd/gridpulse-blog.github.io`). It is excluded from the Jekyll build, so it appears in the
repository but not as pages on the site; the site links to it from `pandapower-studies.html`.
Run everything from inside this folder.

### Interactive results on the website

`python tools/export_web_results.py` runs a grid of 40+ cases (SCR, dead-band, operator bias, VSC power level)
and writes `outputs/web/pandapower-results.json`. That data drives the interactive page
**https://ashu-kd.github.io/gridpulse-blog.github.io/pandapower-studies.html**.

## Results at a glance

**RPC filter switching (script 03)** — with a dead-band narrower than one bank the controller hunts:

![RPC time series](outputs/03_rpc_timeseries.png)

**LCC link sweep (script 01)**

![LCC sweep](outputs/01_lcc_link_sweep.png)

**VSC-HVDC hybrid AC/DC power flow (script 04)**

![VSC hybrid](outputs/04_vsc_hybrid.png)

## Modelling notes

* Per unit on the DC rating (1000 MW by default); AC systems are ideal sources behind a Thevenin
  impedance `Z = 1/SCR` (X/R = 10), so the converter bus voltage responds to reactive power.
* LCC converters are PQ loads (rectifier P > 0, inverter P < 0). Their reactive power follows
  `cos(α+μ) = cos α − 2·dx·Id/U` and `Q/P = (2μ + sin2α − sin2(α+μ)) / (cos2α − cos2(α+μ))`,
  with α (rectifier) / γ (inverter) held by the tap changers.
* IEC 60909 short-circuit power includes the voltage factor c_max = 1.1, so the computed SCR is
  about 10 % above the design value.
* pandapower is a steady-state tool. Current-controller dynamics, VDCOL, commutation failure and
  dq vector control are time-domain topics — see the browser lab or EMT tools
  (PSCAD/EMTDC, EMTP, OpenModelica, ParaEMT).

Tested with pandapower 3.5.6 and Python 3.13.

## Licence

MIT — see `LICENSE`. pandapower itself is BSD-3-Clause.
