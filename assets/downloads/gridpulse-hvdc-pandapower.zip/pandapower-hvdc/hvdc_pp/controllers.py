"""
pandapower controllers for LCC-HVDC stations.

* LCCConverter        — sets the converter's reactive power from the LCC overlap equations,
                        using the active power in net.load and the AC bus voltage.
* RPCFilterController — reactive power control (RPC): minimum-filter schedule, Q-band control
                        with operator bias, U-limit override and a switching delay.

Both follow the standard pandapower Controller interface, so they work with
pp.control.run_control() (static) and pandapower.timeseries.run_timeseries() (quasi-static).
"""
from __future__ import annotations

import logging

import numpy as np
from pandapower.control.basic_controller import Controller

from .lcc import converter_q_pu

logger = logging.getLogger(__name__)


class LCCConverter(Controller):
    """Reactive power of an LCC converter modelled as a pandapower load.

    Parameters
    ----------
    load_index : index in net.load. p_mw > 0 for a rectifier, p_mw < 0 for an inverter.
    angle_deg  : alpha (rectifier) or gamma (inverter), held by the tap changer / CEA control.
    dx         : relative inductive voltage drop at rated current.
    p_rated_mw : converter rating (per-unit base).
    use_ac_voltage : if True the commutation voltage follows the AC bus voltage (tap changer not yet moved).
    """

    def __init__(self, net, load_index, angle_deg=15.0, dx=0.08, p_rated_mw=1000.0, vd_pu=1.0,
                 use_ac_voltage=True, tol_mvar=0.5, order=0, level=0, **kwargs):
        super().__init__(net, order=order, level=level, **kwargs)
        self.load_index = load_index
        self.bus = int(net.load.at[load_index, "bus"])
        self.angle_deg = angle_deg
        self.dx = dx
        self.p_rated_mw = p_rated_mw
        self.vd_pu = vd_pu
        self.use_ac_voltage = use_ac_voltage
        self.tol_mvar = tol_mvar

    def _u(self, net):
        if not self.use_ac_voltage or net.res_bus.empty or self.bus not in net.res_bus.index:
            return 1.0
        u = net.res_bus.at[self.bus, "vm_pu"]
        return 1.0 if not np.isfinite(u) else float(u)

    def q_target_mvar(self, net):
        p_pu = net.load.at[self.load_index, "p_mw"] / self.p_rated_mw
        return converter_q_pu(p_pu, self.angle_deg, self.dx, self._u(net), self.vd_pu) * self.p_rated_mw

    def is_converged(self, net):
        return abs(self.q_target_mvar(net) - net.load.at[self.load_index, "q_mvar"]) < self.tol_mvar

    def control_step(self, net):
        net.load.at[self.load_index, "q_mvar"] = self.q_target_mvar(net)


class RPCFilterController(Controller):
    """Switch AC-filter banks (a stepped pandapower shunt) like an HVDC reactive power controller.

    Rules (same as the GridPulse web lab):
      * banks needed for harmonic performance: one per threshold in `min_filter_p` that P exceeds;
      * Q mode: keep Q_exchange - bias inside +/- band (Q_exchange = Q_filters - Q_converter, + = export);
      * U limits override Q control: switch in below u_min, out above u_max (never below the minimum filter);
      * a Q-band operation is blocked if the expected voltage step would cross a U limit; the expected
        step starts at q_bank / scr_est and is updated with the largest step actually observed;
      * U mode: voltage limits only;
      * delay_steps > 0: a condition must persist for that many time steps (time-series use);
        delay_steps = 0: act immediately inside one run_control (static use).
    All Q values in pu of p_rated_mw.
    """

    def __init__(self, net, shunt_index, converter_load_index, angle_deg=15.0, dx=0.08, p_rated_mw=1000.0,
                 mode="Q", band_pu=0.08, bias_pu=0.0, u_min=0.95, u_max=1.05, min_filter_p=(0.02, 0.5),
                 delay_steps=0, use_ac_voltage=True, scr_est=3.0, order=1, level=0, **kwargs):
        super().__init__(net, order=order, level=level, **kwargs)
        self.shunt_index = shunt_index
        self.load_index = converter_load_index
        self.bus = int(net.shunt.at[shunt_index, "bus"])
        self.angle_deg, self.dx, self.p_rated_mw = angle_deg, dx, p_rated_mw
        self.mode, self.band, self.bias = mode, band_pu, bias_pu
        self.u_min, self.u_max = u_min, u_max
        self.min_filter_p = tuple(sorted(min_filter_p))
        self.delay_steps = int(delay_steps)
        self.use_ac_voltage = use_ac_voltage
        self.q_bank_pu = -net.shunt.at[shunt_index, "q_mvar"] / p_rated_mw
        self.du_bank = self.q_bank_pu / scr_est          # expected voltage step per bank [pu]
        self.n_max = int(net.shunt.at[shunt_index, "max_step"])
        self.events = []
        self.time = None
        self._t_in = self._t_out = 0
        self._evaluated = False
        self._pending = 0
        self._reason = ""
        self._static_ops = 0
        self._u_before = None

    # ---------------------------------------------------------------- helpers
    def state(self, net):
        p_pu = abs(net.load.at[self.load_index, "p_mw"]) / self.p_rated_mw
        u = float(net.res_bus.at[self.bus, "vm_pu"]) if not net.res_bus.empty else 1.0
        if self._u_before is not None:                      # learn the real voltage step of one bank
            self.du_bank = max(self.du_bank, abs(u - self._u_before))
            self._u_before = None
        n = int(net.shunt.at[self.shunt_index, "step"])
        q_conv = converter_q_pu(p_pu, self.angle_deg, self.dx, u if self.use_ac_voltage else 1.0)
        q_filt = n * self.q_bank_pu * u * u
        req = sum(p_pu > th for th in self.min_filter_p)
        return dict(p=p_pu, u=u, n=n, req=req, q_conv=q_conv, q_filt=q_filt, q_ex=q_filt - q_conv)

    def _decide(self, s):
        dev = s["q_ex"] - self.bias
        if self.mode == "U":
            if s["n"] < self.n_max and (s["n"] < s["req"] or s["u"] < self.u_min):
                return 1, "min-filter" if s["n"] < s["req"] else "U-min"
            if s["n"] > s["req"] and s["u"] > self.u_max:
                return -1, "U-max"
            return 0, ""
        can_in, can_out = s["n"] < self.n_max, s["n"] > s["req"]
        if can_in and s["n"] < s["req"]:
            return 1, "min-filter"
        if can_in and s["u"] < self.u_min:
            return 1, "U-min"
        if can_out and s["u"] > self.u_max:
            return -1, "U-max"
        if can_in and dev < -self.band and s["u"] + self.du_bank <= self.u_max:
            return 1, "Q-band"
        if can_out and dev > self.band and s["u"] - self.du_bank >= self.u_min:
            return -1, "Q-band"
        return 0, ""

    # ------------------------------------------------------ controller interface
    def time_step(self, net, time):
        self.time = time
        self._evaluated = False
        self._pending = 0

    def is_converged(self, net):
        if net.res_bus.empty:
            return False
        if self.delay_steps <= 0:                           # static: settle within this run_control
            if self._static_ops >= 2 * self.n_max:
                logger.warning("RPC at bus %s keeps switching (dead-band narrower than a bank?)", self.bus)
                return True
            self._pending, self._reason = self._decide(self.state(net))
            return self._pending == 0
        if not self._evaluated:                             # time series: evaluate once per time step
            self._evaluated = True
            want, reason = self._decide(self.state(net))
            self._t_in = self._t_in + 1 if want > 0 else 0
            self._t_out = self._t_out + 1 if want < 0 else 0
            if self._t_in >= self.delay_steps:
                self._pending, self._reason, self._t_in = 1, reason, 0
            elif self._t_out >= self.delay_steps:
                self._pending, self._reason, self._t_out = -1, reason, 0
        return self._pending == 0

    def control_step(self, net):
        if not self._pending:
            return
        s = self.state(net)
        net.shunt.at[self.shunt_index, "step"] = int(np.clip(s["n"] + self._pending, 0, self.n_max))
        self.events.append(dict(time=self.time, p_pu=round(s["p"], 4), op="IN" if self._pending > 0 else "OUT",
                                banks=int(net.shunt.at[self.shunt_index, "step"]), reason=self._reason,
                                u_before=round(s["u"], 4), q_ex_before=round(s["q_ex"], 4)))
        self._static_ops += 1
        self._u_before = s["u"]
        self._pending = 0
