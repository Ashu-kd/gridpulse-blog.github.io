"""
LCC-HVDC steady-state equations (per unit) — the same formulas used by the
GridPulse HVDC Controller Lab (assets/js/hvdc-models.js), written in NumPy.

Conventions
-----------
* Per unit on the converter rating: P_base = rated DC power, V_base = rated DC voltage.
* dx  = relative inductive voltage drop at rated current (R_c * I_dN / V_do).
* Angles in degrees at the API, radians inside.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

D2R = np.pi / 180.0


def overlap_angle(angle_deg: float, dx: float, id_pu: float, u_pu: float = 1.0) -> float:
    """Commutation overlap mu [deg] from cos(a + mu) = cos(a) - 2*dx*Id/U."""
    a = angle_deg * D2R
    am = np.arccos(np.clip(np.cos(a) - 2.0 * dx * id_pu / max(u_pu, 1e-6), -1.0, 1.0))
    return (am - a) / D2R


def q_over_p(angle_deg: float, dx: float, id_pu: float, u_pu: float = 1.0) -> float:
    """Reactive/active power ratio of a 6/12-pulse bridge (exact overlap formula).

    tan(phi) = (2mu + sin2a - sin2(a+mu)) / (cos2a - cos2(a+mu))
    Use alpha for a rectifier and gamma for an inverter.
    """
    a = angle_deg * D2R
    mu = max(overlap_angle(angle_deg, dx, id_pu, u_pu) * D2R, 1e-9)
    am = a + mu
    return (2 * mu + np.sin(2 * a) - np.sin(2 * am)) / (np.cos(2 * a) - np.cos(2 * am))


def converter_q_pu(p_pu: float, angle_deg: float, dx: float, u_pu: float = 1.0, vd_pu: float = 1.0) -> float:
    """Reactive power absorbed by the converter [pu] for active power p_pu (Id = P / Vd)."""
    p = abs(p_pu)
    if p < 1e-6:
        return 0.0
    return p * q_over_p(angle_deg, dx, p / vd_pu, u_pu)


def vdo_for_rated(gamma_ref_deg: float = 18.0, dx: float = 0.08) -> float:
    """No-load DC voltage that gives 1.0 pu at the inverter at rated current in CEA."""
    return 1.0 / (np.cos(gamma_ref_deg * D2R) - dx)


@dataclass
class LCCOperatingPoint:
    id_pu: float
    vdr_pu: float
    vdi_pu: float
    alpha_deg: float
    gamma_deg: float
    mu_r_deg: float
    mu_i_deg: float
    pr_pu: float
    pi_pu: float
    qr_pu: float
    qi_pu: float


def operating_point(p_order_pu: float, gamma_ref_deg: float = 18.0, dx: float = 0.08, rd_pu: float = 0.03,
                    kr: float = 1.0, ki: float = 1.0) -> LCCOperatingPoint:
    """Static operating point: rectifier on current control, inverter on CEA.

    kr / ki are the rectifier / inverter commutation-voltage factors (1.0 = rated).
    """
    vdo = vdo_for_rated(gamma_ref_deg, dx)
    rc = dx * vdo
    i_d = max(p_order_pu, 0.05)
    for _ in range(50):
        vdi = ki * vdo * np.cos(gamma_ref_deg * D2R) - rc * i_d
        vdr = vdi + rd_pu * i_d
        i_d = p_order_pu / vdr
    cos_a = (vdr + rc * i_d) / (kr * vdo)
    alpha = np.degrees(np.arccos(np.clip(cos_a, -1, 1)))
    mu_r = overlap_angle(alpha, dx * vdo / (kr * vdo), i_d)          # dx scales with 1/k
    mu_i = overlap_angle(gamma_ref_deg, dx * vdo / (ki * vdo), i_d)
    pr, pi = vdr * i_d, vdi * i_d
    qr = pr * q_over_p(alpha, dx / kr, i_d)
    qi = pi * q_over_p(gamma_ref_deg, dx / ki, i_d)
    return LCCOperatingPoint(i_d, vdr, vdi, alpha, gamma_ref_deg, mu_r, mu_i, pr, pi, qr, qi)


def gamma_after_dip(dip: float, phi_deg: float = 0.0, gamma0_deg: float = 18.0, dx: float = 0.08,
                    id0_pu: float = 1.0, surge: float = 1.0) -> float:
    """Inverter extinction angle after a commutation-voltage dip with the firing angle already issued.

    cos(gamma) = cos(beta0 + phi) + 2*dx*Id'/k,  cos(beta0) = cos(gamma0) - 2*dx*Id0.
    Returns 0.0 when commutation fails outright (argument >= 1).
    """
    beta0 = np.arccos(np.cos(gamma0_deg * D2R) - 2 * dx * id0_pu)
    k = max(1.0 - dip, 1e-4)
    arg = np.cos(beta0 + phi_deg * D2R) + 2 * dx * id0_pu * surge / k
    return 0.0 if arg >= 1 else float(np.degrees(np.arccos(arg)))


def critical_dip(phi_deg: float = 0.0, gamma0_deg: float = 18.0, dx: float = 0.08, id0_pu: float = 1.0,
                 surge: float = 1.0, tq_s: float = 400e-6, f_hz: float = 50.0) -> float:
    """Smallest voltage dip (0..1) that drives gamma below gamma_min = omega * t_q."""
    gmin = 2 * np.pi * f_hz * tq_s
    beta0 = np.arccos(np.cos(gamma0_deg * D2R) - 2 * dx * id0_pu)
    den = np.cos(gmin) - np.cos(beta0 + phi_deg * D2R)
    if den <= 0:
        return 0.0
    return float(np.clip(1 - 2 * dx * id0_pu * surge / den, 0, 1))
