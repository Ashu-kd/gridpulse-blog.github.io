"""
Test networks: two AC systems (Thevenin equivalents with a chosen short-circuit ratio)
linked by an HVDC transmission.

    [ext_grid]--Z_th(SCR)--[Rect AC bus]==LCC/VSC==[Inv AC bus]--Z_th(SCR)--[ext_grid]
                               |  filters                |  filters

The Thevenin impedance is created with pandapower's `impedance` element, so the AC
voltage at the converter bus responds to reactive power (unlike an ext_grid bus).
"""
from __future__ import annotations

import numpy as np
import pandapower as pp


def _thevenin(net, source_bus, conv_bus, scr: float, p_rated_mw: float, xr: float):
    """Series impedance giving a short-circuit level of SCR * P_rated (MVA) at conv_bus."""
    z = 1.0 / scr                     # pu on p_rated_mw
    r = z / np.sqrt(1 + xr ** 2)
    pp.create_impedance(net, source_bus, conv_bus, rft_pu=r, xft_pu=r * xr, sn_mva=p_rated_mw,
                        name=f"Thevenin SCR={scr:g}")


def build_lcc_link(p_rated_mw: float = 1000.0, vn_kv: float = 400.0, scr_rect: float = 5.0, scr_inv: float = 4.0,
                   xr: float = 10.0, n_banks: int = 6, qb_pu: float = 0.12, banks_on: int = 1):
    """LCC-HVDC link between two AC systems.

    Converters are modelled as PQ loads whose P and Q are set by `LCCConverter` controllers
    (rectifier: +P consumed, inverter: -P i.e. injected). AC filters / shunt capacitors are one
    stepped `shunt` per station (`step` = banks in service, `max_step` = n_banks).

    Returns (net, ids) where ids is a dict of element indices.
    """
    net = pp.create_empty_network(name="GridPulse LCC-HVDC link", sn_mva=100.0)
    ids = {}
    for side, scr in (("rect", scr_rect), ("inv", scr_inv)):
        src = pp.create_bus(net, vn_kv, name=f"{side} AC system source")
        bus = pp.create_bus(net, vn_kv, name=f"{side} converter AC bus")
        pp.create_ext_grid(net, src, vm_pu=1.0, s_sc_max_mva=1e6, rx_max=0.1, s_sc_min_mva=1e6, rx_min=0.1,
                           name=f"{side} AC system")
        _thevenin(net, src, bus, scr, p_rated_mw, xr)
        load = pp.create_load(net, bus, p_mw=0.0, q_mvar=0.0, name=f"{side} LCC converter")
        q_bank = qb_pu * p_rated_mw
        shunt = pp.create_shunt(net, bus, q_mvar=-q_bank, p_mw=0.0, step=banks_on, max_step=n_banks,
                                name=f"{side} AC filters ({n_banks} x {q_bank:.0f} Mvar)")
        ids[side] = {"source": src, "bus": bus, "load": load, "shunt": shunt, "scr": scr}
    ids["p_rated_mw"] = p_rated_mw
    return net, ids


def build_vsc_link(p_rated_mw: float = 1000.0, vn_kv: float = 400.0, vdc_kv: float = 320.0, length_km: float = 300.0,
                   scr_a: float = 5.0, scr_b: float = 3.0, xr: float = 10.0):
    """Point-to-point VSC-HVDC link using pandapower's hybrid AC/DC power flow.

    Station A controls the DC voltage (DC slack) and its AC reactive power; station B controls
    active power and its AC voltage. Returns (net, ids).
    """
    net = pp.create_empty_network(name="GridPulse VSC-HVDC link", sn_mva=100.0)
    ids = {}
    for side, scr in (("A", scr_a), ("B", scr_b)):
        src = pp.create_bus(net, vn_kv, name=f"{side} AC system source")
        bus = pp.create_bus(net, vn_kv, name=f"{side} PCC")
        pp.create_ext_grid(net, src, vm_pu=1.0, s_sc_max_mva=1e6, rx_max=0.1, name=f"{side} AC system")
        _thevenin(net, src, bus, scr, p_rated_mw, xr)
        dc = pp.create_bus_dc(net, vdc_kv, name=f"{side} DC bus")
        ids[side] = {"source": src, "bus": bus, "bus_dc": dc, "scr": scr}
    # pole conductor: ~0.01 ohm/km, 2 kA thermal limit (per pole, symmetric monopole equivalent)
    ids["line_dc"] = pp.create_line_dc_from_parameters(net, ids["A"]["bus_dc"], ids["B"]["bus_dc"], length_km=length_km,
                                                       r_ohm_per_km=0.01, max_i_ka=2.0, name="DC cable")
    # converter reactor + transformer ~0.15 pu on the station rating
    z_base = vn_kv ** 2 / p_rated_mw
    ids["A"]["vsc"] = pp.create_vsc(net, ids["A"]["bus"], ids["A"]["bus_dc"], r_ohm=0.005 * z_base, x_ohm=0.15 * z_base,
                                    r_dc_ohm=0.5, control_mode_ac="q_mvar", control_value_ac=0.0,
                                    control_mode_dc="vm_pu", control_value_dc=1.0, name="VSC A (Vdc control)")
    ids["B"]["vsc"] = pp.create_vsc(net, ids["B"]["bus"], ids["B"]["bus_dc"], r_ohm=0.005 * z_base, x_ohm=0.15 * z_base,
                                    r_dc_ohm=0.5, control_mode_ac="vm_pu", control_value_ac=1.0,
                                    control_mode_dc="p_mw", control_value_dc=0.0, name="VSC B (P control)")
    ids["p_rated_mw"] = p_rated_mw
    return net, ids
