"""Sanity tests: run with `pytest -q` from the repository root."""
import math

import pandapower as pp
import pandapower.control as control

from hvdc_pp import (LCCConverter, RPCFilterController, build_lcc_link, build_vsc_link, converter_q_pu,
                     critical_dip, gamma_after_dip, operating_point, q_over_p)


def test_q_over_p_limits():
    # with negligible current the ratio tends to tan(alpha)
    assert math.isclose(q_over_p(15.0, 0.08, 1e-4), math.tan(math.radians(15.0)), rel_tol=1e-3)
    # rated load: typical LCC consumes ~0.5-0.6 pu Q per pu P
    assert 0.45 < converter_q_pu(1.0, 15.0, 0.08) < 0.65


def test_operating_point_rated():
    op = operating_point(1.0, gamma_ref_deg=18.0, dx=0.08, rd_pu=0.03)
    assert math.isclose(op.pr_pu, 1.0, rel_tol=1e-6)
    assert 8 < op.alpha_deg < 20
    assert op.vdi_pu < op.vdr_pu


def test_commutation_margin():
    assert gamma_after_dip(0.0) > 17.9
    assert gamma_after_dip(0.4) == 0.0                     # deep dip fails commutation
    d = critical_dip()
    assert 0.15 < d < 0.30
    assert critical_dip(phi_deg=-4.0) < d                  # phase shift reduces immunity


def test_lcc_link_controllers_converge():
    net, ids = build_lcc_link(banks_on=1)
    r = ids["rect"]
    net.load.at[r["load"], "p_mw"] = 800.0
    LCCConverter(net, r["load"], angle_deg=15.0)
    RPCFilterController(net, r["shunt"], r["load"], angle_deg=15.0, delay_steps=0, scr_est=r["scr"])
    control.run_control(net, max_iter=60)
    assert net.load.at[r["load"], "q_mvar"] > 300.0
    assert net.shunt.at[r["shunt"], "step"] >= 2           # minimum filter above 0.5 pu
    assert 0.94 < net.res_bus.at[r["bus"], "vm_pu"] < 1.06


def test_vsc_link_runs():
    net, ids = build_vsc_link()
    net.vsc.at[ids["B"]["vsc"], "control_value_dc"] = 500.0
    pp.runpp(net)
    assert math.isclose(net.res_bus_dc.at[ids["A"]["bus_dc"], "vm_pu"], 1.0, abs_tol=1e-6)
    assert net.res_line_dc.at[ids["line_dc"], "pl_mw"] > 0
