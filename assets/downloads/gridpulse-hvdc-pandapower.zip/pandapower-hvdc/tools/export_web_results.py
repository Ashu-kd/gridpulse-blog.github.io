"""
Export a grid of pandapower results for the GridPulse website (pandapower-studies.html).

Runs the four studies for several system strengths, dead-bands and biases and writes
outputs/web/pandapower-results.json. Run from the repository root:

    python tools/export_web_results.py

Takes a few minutes without numba (the RPC time series dominate); uses all CPU cores.
"""
from __future__ import annotations

import json
import pathlib
import sys
import tempfile
import time
import warnings
from itertools import product
from multiprocessing import Pool

import numpy as np
import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
warnings.filterwarnings("ignore")

P_RATED, DX = 1000.0, 0.08


def r4(a):
    """Round for the web; NaN (no power-flow solution) becomes null."""
    return [None if x is None or not np.isfinite(float(x)) else round(float(x), 4) for x in a]


# ---------------------------------------------------------------- 01 LCC sweep
def lcc_sweep(scr):
    import pandapower.control as control
    from hvdc_pp import LCCConverter, RPCFilterController, build_lcc_link
    net, ids = build_lcc_link(p_rated_mw=P_RATED, scr_rect=scr, scr_inv=scr, n_banks=6, qb_pu=0.12, banks_on=1)
    for side, angle in (("rect", 15.0), ("inv", 18.0)):
        LCCConverter(net, ids[side]["load"], angle_deg=angle, dx=DX, p_rated_mw=P_RATED)
        RPCFilterController(net, ids[side]["shunt"], ids[side]["load"], angle_deg=angle, dx=DX, p_rated_mw=P_RATED,
                            band_pu=0.08, min_filter_p=(0.02, 0.5), delay_steps=0, scr_est=scr)
    out = {k: [] for k in ("P", "rect_Qconv", "rect_Qfilt", "rect_U", "rect_banks", "inv_Qconv", "inv_Qfilt", "inv_U",
                           "inv_banks")}
    for p in np.round(np.arange(0.05, 1.0001, 0.05), 2):
        net.load.at[ids["rect"]["load"], "p_mw"] = p * P_RATED
        net.load.at[ids["inv"]["load"], "p_mw"] = -p * P_RATED * 0.985
        out["P"].append(float(p))
        try:
            control.run_control(net, max_iter=80, max_iteration=30)
        except Exception:                      # no AC solution: voltage collapse on a very weak system
            for side in ("rect", "inv"):
                for k in ("Qconv", "Qfilt", "U", "banks"):
                    out[f"{side}_{k}"].append(None)
            out.setdefault("collapse_from", float(p))
            continue
        for side in ("rect", "inv"):
            out[f"{side}_Qconv"].append(net.load.at[ids[side]["load"], "q_mvar"] / P_RATED)
            out[f"{side}_Qfilt"].append(-net.res_shunt.at[ids[side]["shunt"], "q_mvar"] / P_RATED)
            out[f"{side}_U"].append(net.res_bus.at[ids[side]["bus"], "vm_pu"])
            out[f"{side}_banks"].append(int(net.shunt.at[ids[side]["shunt"], "step"]))
    return {k: (v if k.endswith("banks") or k in ("P", "collapse_from") else r4(v)) for k, v in out.items()}


# ------------------------------------------------------- 02 SCR & voltage steps
def scr_steps(scr):
    import pandapower as pp
    import pandapower.shortcircuit as sc
    from hvdc_pp import build_lcc_link
    net, ids = build_lcc_link(p_rated_mw=P_RATED, scr_rect=scr, scr_inv=scr, n_banks=6, qb_pu=0.12, banks_on=0)
    bus = ids["inv"]["bus"]
    sc.calc_sc(net, case="max", bus=bus)
    s_sc = float(net.res_bus_sc.at[bus, "skss_mw"])
    u = []
    for n in range(7):
        net.shunt.at[ids["inv"]["shunt"], "step"] = n
        pp.runpp(net)
        u.append(net.res_bus.at[bus, "vm_pu"])
    return {"design": scr, "s_sc": round(s_sc, 1), "scr": round(s_sc / P_RATED, 3), "U": r4(u)}


# ------------------------------------------------------------ 03 RPC time series
def rpc_case(args):
    band, scr, bias = args
    from pandapower.control import ConstControl
    from pandapower.timeseries import DFData, OutputWriter, run_timeseries
    from hvdc_pp import LCCConverter, RPCFilterController, build_lcc_link
    up = np.arange(0.1, 1.0 + 1e-9, 0.01)
    prof = pd.DataFrame({"p": np.concatenate([np.full(20, 0.1), up, np.full(20, 1.0), up[::-1], np.full(20, 0.1)]) * P_RATED})
    net, ids = build_lcc_link(p_rated_mw=P_RATED, scr_rect=scr, scr_inv=scr, n_banks=6, qb_pu=0.12, banks_on=1)
    r = ids["rect"]
    net.load.at[ids["inv"]["load"], "in_service"] = False
    net.shunt.at[ids["inv"]["shunt"], "in_service"] = False
    ConstControl(net, element="load", variable="p_mw", element_index=[r["load"]], data_source=DFData(prof),
                 profile_name=["p"], order=0)
    LCCConverter(net, r["load"], angle_deg=15.0, dx=DX, p_rated_mw=P_RATED, order=1)
    rpc = RPCFilterController(net, r["shunt"], r["load"], angle_deg=15.0, dx=DX, p_rated_mw=P_RATED, band_pu=band,
                              bias_pu=bias, u_min=0.95, u_max=1.05, min_filter_p=(0.02, 0.5), delay_steps=2,
                              scr_est=scr, order=2)
    with tempfile.TemporaryDirectory() as tmp:
        ow = OutputWriter(net, time_steps=prof.index, output_path=tmp, output_file_type=".json")
        ow.log_variable("res_bus", "vm_pu", index=[r["bus"]])
        ow.log_variable("load", "q_mvar", index=[r["load"]])
        ow.log_variable("res_shunt", "q_mvar", index=[r["shunt"]])
        ow.log_variable("shunt", "step", index=[r["shunt"]])
        run_timeseries(net, time_steps=prof.index, verbose=False, continue_on_divergence=True)
        qc = ow.output["load.q_mvar"][r["load"]].values / P_RATED
        qf = -ow.output["res_shunt.q_mvar"][r["shunt"]].values / P_RATED
        res = {"P": r4(prof.p.values / P_RATED), "U": r4(ow.output["res_bus.vm_pu"][r["bus"]].values),
               "Qconv": r4(qc), "Qfilt": r4(qf), "banks": [int(x) if np.isfinite(x) else None for x in ow.output["shunt.step"][r["shunt"]].values]}
    res["events"] = [{k: (v if not isinstance(v, (np.floating, np.integer)) else v.item()) for k, v in e.items()}
                     for e in rpc.events]
    return f"{band}|{scr}|{bias}", res


# ------------------------------------------------------------------- 04 VSC link
def vsc_case(scr_b):
    import pandapower as pp
    from hvdc_pp import build_vsc_link
    net, ids = build_vsc_link(p_rated_mw=P_RATED, scr_a=5.0, scr_b=scr_b, length_km=300)
    A, B = ids["A"], ids["B"]
    out = {k: [] for k in ("P", "Q_B", "Vdc_B", "loss", "U_A")}
    for p in np.round(np.arange(-1.0, 1.0001, 0.1), 2) + 0.0:
        net.vsc.at[B["vsc"], "control_value_dc"] = p * P_RATED
        try:
            pp.runpp(net)
        except Exception:
            continue
        out["P"].append(float(p))
        out["Q_B"].append(net.res_vsc.at[B["vsc"], "q_mvar"] / P_RATED)
        out["Vdc_B"].append(net.res_bus_dc.at[B["bus_dc"], "vm_pu"])
        out["loss"].append(net.res_line_dc.at[ids["line_dc"], "pl_mw"])
        out["U_A"].append(net.res_bus.at[A["bus"], "vm_pu"])
    return {k: (v if k == "P" else r4(v)) for k, v in out.items()}


def vsc_q_case(args):
    scr, p_pu = args
    import pandapower as pp
    from hvdc_pp import build_vsc_link
    net, ids = build_vsc_link(p_rated_mw=P_RATED, scr_a=scr, scr_b=5.0)
    net.vsc.at[ids["B"]["vsc"], "control_value_dc"] = -p_pu * P_RATED
    q_ord, u = [], []
    for q in np.round(np.arange(-0.6, 0.6001, 0.05), 3):
        net.vsc.at[ids["A"]["vsc"], "control_value_ac"] = q * P_RATED
        try:
            pp.runpp(net)
        except Exception:
            continue
        q_ord.append(float(q)); u.append(net.res_bus.at[ids["A"]["bus"], "vm_pu"])
    return f"{scr}|{p_pu}", {"Q": q_ord, "U": r4(u)}


if __name__ == "__main__":
    import pandapower
    t0 = time.time()
    data = {"meta": {"pandapower": pandapower.__version__, "generated": time.strftime("%Y-%m-%d"),
                     "p_rated_mw": P_RATED, "bank_pu": 0.12, "n_banks": 6}}
    with Pool() as pool:
        rpc_jobs = list(product((0.04, 0.06, 0.08, 0.10), (3.0, 4.0, 5.0), (0.0, 0.1)))
        rpc_async = pool.map_async(rpc_case, rpc_jobs)
        data["lcc"] = dict(zip(["2.5", "3", "4", "5", "8"], pool.map(lcc_sweep, (2.5, 3.0, 4.0, 5.0, 8.0))))
        data["scr"] = pool.map(scr_steps, (2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0))
        data["vsc"] = dict(zip(["2", "3", "5"], pool.map(vsc_case, (2.0, 3.0, 5.0))))
        data["vsc_q"] = dict(pool.map(vsc_q_case, list(product((2.0, 3.0, 5.0), (0.0, 0.4, 0.8)))))
        data["rpc"] = dict(rpc_async.get())
    out = ROOT / "outputs" / "web"
    out.mkdir(parents=True, exist_ok=True)
    path = out / "pandapower-results.json"
    path.write_text(json.dumps(data, separators=(",", ":")))
    print(f"wrote {path} ({path.stat().st_size / 1024:.0f} kB) in {time.time() - t0:.0f} s")
